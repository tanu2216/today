package com.capgemini.pcm.repo;

import com.capgemini.pcm.beans.Product;
import com.capgemini.pcm.exception.IdAlreadyExistsException;
import com.capgemini.pcm.exception.ProductIdNotFoundException;
import java.util.List;
import javax.transaction.Transactional;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;



@Repository
public class ProductRepoImpl implements ProductRepo {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public boolean saveNewProduct(Product product){
		
		entityManager.persist(product);
		return true;
	}

	@Override
	public Product find(String id){
		
		Product product=entityManager.find(Product.class, id);
	
		return product;
	}
	
	@Override
	public List<Product> findAllProducts() {
		
		 Query query = entityManager.
			      createQuery("Select p from Product p");
			      List<Product> list = query.getResultList();
			     return list;
		
	}
	
	@Override
	@Transactional
	public Product updateProduct(Product product)	{
		
		Product p=entityManager.find(Product.class, product.getId());
		p.setId(product.getId());
		p.setModel(product.getModel());
		p.setName(product.getName());		
		p.setPrice(product.getPrice());
		entityManager.persist(p);
		return p;
	}

	@Override
	@Transactional
	public boolean deleteById(String id) {
		Product p=entityManager.find(Product.class,id);
		entityManager.remove(p);
		return true;
	}

}
