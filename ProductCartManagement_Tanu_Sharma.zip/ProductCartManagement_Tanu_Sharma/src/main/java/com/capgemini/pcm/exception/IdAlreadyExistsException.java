package com.capgemini.pcm.exception;

public class IdAlreadyExistsException extends RuntimeException{

	@Override
	public String getMessage() {
		return "Product Id Already Exists!!";
	}
	
}
