package com.capgemini.pcm.service;


import java.util.List;
import com.capgemini.pcm.beans.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.pcm.exception.IdAlreadyExistsException;
import com.capgemini.pcm.exception.ProductIdNotFoundException;
import com.capgemini.pcm.repo.ProductRepoImpl;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepoImpl productRepoImpl;
	
	@Override
	public boolean addNewProduct(Product product) {
		if(productRepoImpl.find(product.getId())!=null)
		{
			throw new IdAlreadyExistsException();
		}
		return productRepoImpl.saveNewProduct(product);
		
	}
	
	@Override
	public Product findById(String id) {
		
		if(productRepoImpl.find(id)==null)
		{
			throw new ProductIdNotFoundException();
		}
		return productRepoImpl.find(id) ;
	}
	
	@Override
	public List<Product> findAllProducts() {
		
		return productRepoImpl.findAllProducts();
		
	}


	@Override
	public Product updateProduct(Product product) {

		if(productRepoImpl.find(product.getId())==null)
		{
			throw new ProductIdNotFoundException();
		}
		
		return  productRepoImpl.updateProduct(product) ;
	}
	
	@Override
	public boolean deleteById(String id) {
	
		if(productRepoImpl.find(id)==null)
		{
			throw new ProductIdNotFoundException();
		}
		
		return productRepoImpl.deleteById(id);
	}
	
}
