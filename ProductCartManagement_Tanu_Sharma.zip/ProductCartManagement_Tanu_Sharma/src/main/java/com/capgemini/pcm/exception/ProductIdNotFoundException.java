package com.capgemini.pcm.exception;

public class ProductIdNotFoundException extends RuntimeException {

	@Override
	public String getMessage() {
		return "Product Id Does not Exist in the Database";
	}
	
}
