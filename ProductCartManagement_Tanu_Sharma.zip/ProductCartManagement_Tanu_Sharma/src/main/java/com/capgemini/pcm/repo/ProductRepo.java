package com.capgemini.pcm.repo;

import java.util.List;

import com.capgemini.pcm.beans.Product;
import com.capgemini.pcm.exception.IdAlreadyExistsException;
import com.capgemini.pcm.exception.ProductIdNotFoundException;

public interface ProductRepo {

	boolean saveNewProduct(Product product) ;
	
	Product find(String id) ;
	
	List<Product> findAllProducts();
	
	Product updateProduct(Product product);
	
	boolean deleteById(String Id);
	
}
