package com.capgemini.pcm.service;

import java.util.List;
import com.capgemini.pcm.beans.Product;

public interface ProductService {
	
	boolean addNewProduct(Product product) ;
	
	Product findById(String id);
	
	List<Product> findAllProducts();
	
	Product updateProduct(Product product);	
	
	boolean deleteById(String id);
	
}
