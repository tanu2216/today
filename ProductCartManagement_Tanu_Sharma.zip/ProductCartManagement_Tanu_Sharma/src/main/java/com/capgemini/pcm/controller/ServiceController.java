package com.capgemini.pcm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.pcm.beans.Product;
import com.capgemini.pcm.service.ProductServiceImpl;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;



@RestController
public class ServiceController {
	
	@Autowired
	ProductServiceImpl productServiceImpl;
	
	@RequestMapping(value="/addProduct", method=RequestMethod.POST)
	public boolean addProduct(@RequestBody Product product)
	{
		return productServiceImpl.addNewProduct(product);
	}
	
	@RequestMapping(value="/findById/{id}", method=RequestMethod.GET)
	public Product findById(@PathVariable String id)
	{
		return productServiceImpl.findById(id);
	}
	
	@RequestMapping(value="/findAllProducts", method=RequestMethod.GET)
	public List<Product> findAllProducts()
	{
		return productServiceImpl.findAllProducts();
	}
	
	
	@RequestMapping(value="/updateProductDetail", method=RequestMethod.PUT)
	public Product updateProductDetails(@RequestBody Product updatedProduct)
	{
		return productServiceImpl.updateProduct(updatedProduct) ;
	}
	
	

	@RequestMapping(value="/deleteById/{id}", method=RequestMethod.DELETE)
	public boolean deleteById(@PathVariable String id)
	{
		return productServiceImpl.deleteById(id);
	}
	
	
	
}
